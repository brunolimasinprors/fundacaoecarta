
 <!--
 <span class="glyphicon glyphicon-menu-left area3navegacao"> 
 </span> 
 -->
      
<div class="col-sm-12 col-md-4">
    <div class="thumbnail">
	    <img src="http://placehold.it/290x193" alt="">
    	<div class="caption text-justify">
    		<p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
    	</div>
	</div>
</div>

<div class="col-sm-12 col-md-4">
    <div class="thumbnail">
	    <img src="http://placehold.it/290x193" alt="">
    	<div class="caption text-justify">
    		<p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
    	</div>
	</div>
</div>

<div class="col-sm-12 col-md-4">
    <div class="thumbnail text-justify">
	    <img src="http://placehold.it/290x193" alt="">
    	<div class="caption">
    		<p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
    	</div>
	</div>
</div>



<!--
 <span class="glyphicon glyphicon-menu-right area3navegacao"> 
 </span> 
 -->


